import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns
import string
import nltk
nltk.download('punkt')
nltk.download('stopwords')


data=pd.read_csv('youtube.csv')
data.head()
data.info()
data.isnull().sum()
data['category'].unique()
sns.countplot(data['category'])
plt.show()
punct=string.punctuation
punct
def remove_punct(text):
    text_nonpunct=''.join([char for char in text if char not in punct])
    return text_nonpunct
data['text_nonpunct']=data['description'].apply(lambda x:remove_punct(x.lower()))

data.head()
from nltk.tokenize import word_tokenize
def tokenize(text):
    tokens=word_tokenize(text)
    return tokens
data['text_tokenize']=data['text_nonpunct'].apply(lambda x:tokenize(x))

data.head()
from nltk.corpus import stopwords
StopWords=stopwords.words('english')
StopWords

def remove_stopwords(text):
    text=[word for word in text if word not in StopWords]
    return text

data['text_nonStopwords']=data['text_tokenize'].apply(lambda x:remove_stopwords(x))

# Texts to Sequences
from tensorflow import keras
tokenizer = keras.preprocessing.text.Tokenizer()
tokenizer.fit_on_texts(data['text_nonStopwords'])
data['text_sequences'] = tokenizer.texts_to_sequences(data['text_nonStopwords'])

data.head()

len(data['text_sequences'])
(data['text_sequences'].apply(lambda x:len(x)))/len(data['text_sequences'])
input_shape=int(sum(data['text_sequences'].apply(lambda x:len(x)))/len(data['text_sequences']))
input_shape

# Sequence Padding
from keras.preprocessing.sequence import pad_sequences
X=pad_sequences(data['text_sequences'],maxlen=45)
y=data['category']
from sklearn.preprocessing import LabelEncoder
LB=LabelEncoder()
y=LB.fit_transform(y)
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, 
                                                    random_state=100) # encoded_matrix
print("X_train : \n",X_train)
print("X_test  : \n",X_test)
print("X_train shape : ",X_train.shape)
print("X_test  shape : ",X_test.shape)
Max_words=(max(map(max, X)))+1
Max_words
model = keras.models.Sequential([
    keras.layers.Embedding(Max_words, 64, input_shape= [input_shape]), 
    keras.layers.LSTM(16),
    keras.layers.Dropout(0.25),
    keras.layers.Dense(4, activation="softmax")
])
print(model.summary())

# Compiling the model
model.compile(loss='sparse_categorical_crossentropy', optimizer="adam", metrics=["accuracy"])

# Training and evaluating the model
history = model.fit(X_train, y_train, epochs=25, batch_size=32, validation_split=0.2)
# plot the learning curves
import pandas as pd
import matplotlib.pyplot as plt
pd.DataFrame(history.history).plot(figsize=(12, 8))
plt.grid(True)
plt.gca().set_ylim(0, 1) # set the vertical range to [0-1]
plt.show()

# Evaluate the model
model_evaluate = model.evaluate(X_test, y_test)
print("Loss     : ",model_evaluate[0])
print("accuracy : ",model_evaluate[1])

# Confusion Matrix
y_pred = (model.predict(X_test).argmax(axis=-1)).tolist()

class_names = LB.classes_

# Compute classification report
from sklearn.metrics import classification_report, confusion_matrix
print("Classification report : \n",classification_report(y_test, y_pred, target_names = class_names))

# Function to draw confusion matrix
import seaborn as sns
def draw_confusion_matrix(true, preds, normalize=None):
  # Compute confusion matrix
  conf_matx = confusion_matrix(true, preds, normalize = normalize)
  conf_matx = np.round(conf_matx, 2)
  # print(conf_matx)

  # plt.subplots(figsize=(14,8))
  sns.heatmap(conf_matx, annot=True, annot_kws={"size": 12},fmt="g", cbar=False, cmap="viridis")
  plt.show()

print("Confusion matrix : \n")
draw_confusion_matrix(y_test, y_pred)

print("Normalized confusion matrix : \n")
draw_confusion_matrix(y_test, y_pred,"true")

