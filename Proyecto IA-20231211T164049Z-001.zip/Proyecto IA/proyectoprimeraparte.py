import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import string
from nltk.tokenize import word_tokenize
import nltk
# nltk.download('stopwords')
from nltk.corpus import stopwords



data = pd.read_csv('youtube.csv')
data.head()
print(data.description[0])
data.shape
# getting count of null values
data.isnull().sum()
# getting unqiue values of "category" Column
data['category'].unique()
# getting the frequency count for each category in "category" columns
category_valueCounts = data['category'].value_counts()
category_valueCounts
plt.figure(figsize=(12,8))
plt.pie(category_valueCounts,labels=category_valueCounts.index, autopct='%1.1f%%',
        shadow=True, startangle=90)
plt.show()