% Especifica el nombre del archivo CSV de entrada y el nombre del archivo Excel de salida
archivo_csv = 'Rúbrica del Póster (1).csv';
archivo_excel = 'Rubrica4.xlsx';

% Lee el archivo CSV con codificación utf-8
tabla = readtable(archivo_csv, 'Delimiter', ',', 'ReadVariableNames', true, 'TextType', 'string', 'PreserveVariableNames', true);

% Escribe la tabla en un archivo Excel
writetable(tabla, archivo_excel, 'FileType', 'spreadsheet', 'WriteVariableNames', true);

